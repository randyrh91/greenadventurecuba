<?php
/**
 * Created by Ciber-Soft.
 * User: pr0x
 * Date: 30/07/16
 * Time: 14:50
 */
define('L_ENCUENTRELO','[:en]Spot Here![:es]¡Encuentrelo Aqui!');
define('CS_L_NOMBRE','[:en]Name[:es]Nombre');
define('CS_L_PROCESS', '[:en]Wait results of the action[:es]Esperando por el resultado de la acción');
define('CS_L_RESERVA','[:en]Book now for single[:es]Reserve ahora por solo');
define('CS_L_CAPTCHA_ERROR','[:en]The written characters are not the correct ones[:es]Los caracteres escritos no son los correctos');
define('CS_L_RESERVA_IP','[:en]Personal information[:es]Información personal');
define('CS_L_RESERVA_IR','[:en]Information on the book[:es]Información sobre la reserva');
define('CS_L_RESERVA_BD','[:en]Leave a brief description here[:es]Deje aquí una breve descripción');
define('CS_L_RESERVA_BUTTON','[:en]SEND BOOK[:es]ENVIAR RESERVA');
define('CS_L_IMG_COMM','[:en]<label>[Optionally] Add an image (.jpg only)</label>[:es]<label>[Opcional] Adicione una imagen al comentario (solo .jpg)</label>');
