<?php return array (
  'color1' => '#adadb0',
  'color2' => '#5a5b5c',
  'color3' => '#9de8ff',
  'color4' => '#f4fcff',
  'color5' => '#d18a50',
);