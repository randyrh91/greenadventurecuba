<div class="clear"></div>
<?php include (TEMPLATEPATH . '/bottom.php'); ?>
<div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="fcred">
                    Copyright &copy; <?php echo date('Y');?> <a href="<?php bloginfo('siteurl'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> - <?php bloginfo('description'); ?>.<br />
                    Website by Ciber-Soft
                    <?php //fflink(); ?>
                </div>
            </div>

        </div>
    </div>
<div class='clear'></div>	
<?php wp_footer(); ?>
</div>
</body>
</html>      
